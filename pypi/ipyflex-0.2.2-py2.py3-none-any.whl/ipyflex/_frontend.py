#!/usr/bin/env python
# coding: utf-8

# Copyright (c) Trung Le.
# Distributed under the terms of the Modified BSD License.

"""
Information about the frontend package of the widgets.
"""

module_name = 'ipyflex'
module_version = '^0.2.2'
